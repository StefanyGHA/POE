﻿namespace PresentationLayer.Forms
{
    partial class StudentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvStudent = new DataGridView();
            btnDeleteStudent = new Button();
            btnEditStudent = new Button();
            btnSaveStudent = new Button();
            txtNameStudent = new TextBox();
            nameStudent = new Label();
            studentAdmin = new Label();
            btnShowCareers = new Button();
            txtLastNameStudent = new TextBox();
            label1 = new Label();
            careerStudent = new Label();
            cbxCareerStudent = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)dgvStudent).BeginInit();
            SuspendLayout();
            // 
            // dgvStudent
            // 
            dgvStudent.AllowUserToAddRows = false;
            dgvStudent.AllowUserToDeleteRows = false;
            dgvStudent.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvStudent.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvStudent.Location = new Point(397, 101);
            dgvStudent.MultiSelect = false;
            dgvStudent.Name = "dgvStudent";
            dgvStudent.ReadOnly = true;
            dgvStudent.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvStudent.Size = new Size(382, 299);
            dgvStudent.TabIndex = 17;
            // 
            // btnDeleteStudent
            // 
            btnDeleteStudent.Location = new Point(246, 348);
            btnDeleteStudent.Name = "btnDeleteStudent";
            btnDeleteStudent.Size = new Size(75, 23);
            btnDeleteStudent.TabIndex = 16;
            btnDeleteStudent.Text = "Eliminar";
            btnDeleteStudent.UseVisualStyleBackColor = true;
            // 
            // btnEditStudent
            // 
            btnEditStudent.Location = new Point(127, 348);
            btnEditStudent.Name = "btnEditStudent";
            btnEditStudent.Size = new Size(75, 23);
            btnEditStudent.TabIndex = 15;
            btnEditStudent.Text = "Editar";
            btnEditStudent.UseVisualStyleBackColor = true;
            // 
            // btnSaveStudent
            // 
            btnSaveStudent.Location = new Point(12, 348);
            btnSaveStudent.Name = "btnSaveStudent";
            btnSaveStudent.Size = new Size(75, 23);
            btnSaveStudent.TabIndex = 14;
            btnSaveStudent.Text = "Guardar";
            btnSaveStudent.UseVisualStyleBackColor = true;
            // 
            // txtNameStudent
            // 
            txtNameStudent.Location = new Point(12, 85);
            txtNameStudent.Name = "txtNameStudent";
            txtNameStudent.Size = new Size(320, 23);
            txtNameStudent.TabIndex = 12;
            // 
            // nameStudent
            // 
            nameStudent.AutoSize = true;
            nameStudent.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            nameStudent.Location = new Point(12, 52);
            nameStudent.Name = "nameStudent";
            nameStudent.Size = new Size(190, 21);
            nameStudent.TabIndex = 10;
            nameStudent.Text = "Nombre del Estudiante:";
            // 
            // studentAdmin
            // 
            studentAdmin.AutoSize = true;
            studentAdmin.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            studentAdmin.Location = new Point(267, 9);
            studentAdmin.Name = "studentAdmin";
            studentAdmin.Size = new Size(274, 25);
            studentAdmin.TabIndex = 9;
            studentAdmin.Text = "Administrador de Estudiantes";
            // 
            // btnShowCareers
            // 
            btnShowCareers.Location = new Point(246, 415);
            btnShowCareers.Name = "btnShowCareers";
            btnShowCareers.Size = new Size(306, 23);
            btnShowCareers.TabIndex = 18;
            btnShowCareers.Text = "Ver Carreras";
            btnShowCareers.UseVisualStyleBackColor = true;
            // 
            // txtLastNameStudent
            // 
            txtLastNameStudent.Location = new Point(12, 167);
            txtLastNameStudent.Name = "txtLastNameStudent";
            txtLastNameStudent.Size = new Size(320, 23);
            txtLastNameStudent.TabIndex = 20;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(12, 130);
            label1.Name = "label1";
            label1.Size = new Size(192, 21);
            label1.TabIndex = 19;
            label1.Text = "Apellido del Estudiante:";
            // 
            // careerStudent
            // 
            careerStudent.AutoSize = true;
            careerStudent.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            careerStudent.Location = new Point(12, 223);
            careerStudent.Name = "careerStudent";
            careerStudent.Size = new Size(182, 21);
            careerStudent.TabIndex = 21;
            careerStudent.Text = "Carrera del Estudiante:";
            // 
            // cbxCareerStudent
            // 
            cbxCareerStudent.FormattingEnabled = true;
            cbxCareerStudent.Location = new Point(12, 264);
            cbxCareerStudent.Name = "cbxCareerStudent";
            cbxCareerStudent.Size = new Size(320, 23);
            cbxCareerStudent.TabIndex = 22;
            // 
            // StudentForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(cbxCareerStudent);
            Controls.Add(careerStudent);
            Controls.Add(txtLastNameStudent);
            Controls.Add(label1);
            Controls.Add(btnShowCareers);
            Controls.Add(dgvStudent);
            Controls.Add(btnDeleteStudent);
            Controls.Add(btnEditStudent);
            Controls.Add(btnSaveStudent);
            Controls.Add(txtNameStudent);
            Controls.Add(nameStudent);
            Controls.Add(studentAdmin);
            Name = "StudentForm";
            Text = "StudentForm";
            ((System.ComponentModel.ISupportInitialize)dgvStudent).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvStudent;
        private Button btnDeleteStudent;
        private Button btnEditStudent;
        private Button btnSaveStudent;
        private TextBox txtNameStudent;
        private Label nameStudent;
        private Label studentAdmin;
        private Button btnShowCareers;
        private TextBox txtLastNameStudent;
        private Label label1;
        private Label careerStudent;
        private ComboBox cbxCareerStudent;
    }
}