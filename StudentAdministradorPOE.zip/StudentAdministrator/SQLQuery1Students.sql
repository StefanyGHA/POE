USE StudentAdministratorDB
GO

CREATE TABLE student(
	idStudent INT PRIMARY KEY IDENTITY(1,1),
	nameStudent NVARCHAR(50) NOT NULL,
	lastNameStudent NVARCHAR(50) NOT NULL,
	idCareerStudent INT FOREIGN KEY REFERENCES career(idCareer)
)

INSERT INTO student VALUES('Stefany','Argueta',1)